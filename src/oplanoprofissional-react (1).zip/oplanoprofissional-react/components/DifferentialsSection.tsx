import { motion } from "framer-motion";

const differentials = [
  {
    title: "Sistema CRM + Comercial",
    description: "Desenvolvemos um sistema próprio de CRM e acompanhamento comercial para uso diário de vendedores e secretárias. Com ele, organizamos a rotina de atendimento e transformamos conversas em dados, entregando análises e indicadores claros de eficiência e performance.",
    highlight: "Scripts + Rotina + Geração de Demanda + Métricas",
    image: "https://www.studio131.com.br/wp-content/uploads/2026/02/8-1.png"
  },
  {
    title: "Trabalho em equipe",
    description: "Nossa atuação conta com um time com fome de trabalhar.",
    team: [
      "Igor Gagliardi | Estrategista de Marca",
      "Vitor Casaletti | Produtor de Conteúdo", 
      "Higgor Trida | Gestor de Tráfego",
      "Rayani Alberganti | Social Media",
      "Victor Hugo | Editor de Conteúdo",
      "Christopher Cardonha | Editor de Conteúdo"
    ],
    image: "https://www.studio131.com.br/wp-content/uploads/2026/02/5-1.png"
  },
  {
    title: "Resultados sólidos e experiência em tráfego orgânico",
    description: "Incentivamos e estudamos a fundo a geração de demanda com conteúdo orgânico, reduzindo a dependência e o investimento em mídia paga.",
    image: "https://www.studio131.com.br/wp-content/uploads/2026/02/7-1.png"
  },
  {
    title: "Atendemos em estúdio ou in loco",
    description: "No Plano Profissional, nossa atuação é somente na região de Catanduva (SP), onde temos escritório e estúdio próprio pra atender nossos clientes com estrutura completa. As captações acontecem na cidade e nos arredores, em estúdio ou no local indicado, pra garantir diversidade.",
    image: "https://www.studio131.com.br/wp-content/uploads/2026/02/6-1.png"
  }
];

const DifferentialsSection = () => {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {differentials.map((item, index) => (
            <motion.div
              key={index}
              className="card-dark overflow-hidden"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              {/* Imagem */}
              <div className="aspect-video overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Conteúdo */}
              <div className="p-6">
                <h3 
                  className="font-body text-xl font-medium mb-3"
                  style={{ color: '#F6FAFF' }}
                >
                  {item.title}
                </h3>
                
                <p 
                  className="font-ui text-base leading-relaxed mb-3"
                  style={{ color: 'rgba(229, 229, 229, 0.57)' }}
                >
                  {item.description}
                </p>
                
                {/* Lista do time */}
                {item.team && (
                  <ul className="space-y-1 mt-4">
                    {item.team.map((member, i) => (
                      <li 
                        key={i}
                        className="font-ui text-sm"
                        style={{ color: '#E6B281' }}
                      >
                        {member}
                      </li>
                    ))}
                  </ul>
                )}
                
                {/* Highlight */}
                {item.highlight && (
                  <p 
                    className="font-ui text-sm font-medium mt-4"
                    style={{ color: '#E6B281' }}
                  >
                    {item.highlight}
                  </p>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DifferentialsSection;
